package com.learn.ws;

public class StringOperations {

	public String concatString(String s1,String s2)
	{
		return s1+s2;
	}
	public String compareString(String s1,String s2)
	{
		if(s1.equals(s2))
				return "equal";
		return "not equal";
	}
	public String palindrome(String s1)
	{
		StringBuilder sb=new StringBuilder(s1);  
		sb.reverse();  
		String rev= sb.toString();
		if(s1.equals(rev))
				return "palindrome";
		return "not palindrome";
	}
}
