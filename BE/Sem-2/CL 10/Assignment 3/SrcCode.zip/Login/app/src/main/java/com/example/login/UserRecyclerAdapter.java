package com.example.login;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

public class UserRecyclerAdapter extends RecyclerView.Adapter<UserRecyclerAdapter.ViewHolder>{
    private Users[] listdata;
    public Activity context;

    // RecyclerView recyclerView;
    public UserRecyclerAdapter(Users[] listdata) {
        this.listdata = listdata;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.user_recycler_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Users myListData = listdata[position];
        holder.username.setText(listdata[position].getUsername()+"  ");
        holder.phoneno.setText(listdata[position].getPhoneNumber()+"  ");
        holder.name.setText(listdata[position].getName()+"  ");
        holder.gender.setText(listdata[position].getGender()+"  ");
        holder.password.setText(listdata[position].getPassword()+"  ");
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context,UserEdit.class);
                i.putExtra("username", listdata[position].getUsername());

                context.startActivity(i);
//                myListData.updateUser(listdata[position].getUsername());
                Toast.makeText(view.getContext()," clicked on edit",Toast.LENGTH_LONG).show();
            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHandler db = new DatabaseHandler(context);
                db.deleteUser(listdata[position]);
                Toast.makeText(view.getContext(),listdata[position].getUsername() + " User Deleted",Toast.LENGTH_LONG).show();
            }
        });
    }


    @Override
    public int getItemCount() {
        return listdata.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView edit;
        public ImageView delete;
        public TextView phoneno;
        public TextView username;
        public TextView password;
        public TextView gender;
        public TextView name;
        public ViewHolder(View itemView) {
            super(itemView);
            this.edit = (ImageView) itemView.findViewById(R.id.edit_recycler_user);
            this.delete = (ImageView) itemView.findViewById(R.id.delete_recycler_user);
            this.phoneno = (TextView) itemView.findViewById(R.id.phone_recycler);
            this.username = (TextView) itemView.findViewById(R.id.username_recycler);
            this.name = (TextView) itemView.findViewById(R.id.name_recycler);
            this.password = (TextView) itemView.findViewById(R.id.pass_recycler);
            this.gender = (TextView) itemView.findViewById(R.id.gender_recycler);
        }
    }
}
