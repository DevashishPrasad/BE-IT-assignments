package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class UserEdit extends AppCompatActivity {

    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_edit);
        db = new DatabaseHandler(UserEdit.this);

        Intent intent = getIntent();
        ((EditText) findViewById(R.id.uname_edit)).setText(intent.getStringExtra("username"));
    }

    public void checkandedit(View view) {
        String uname = ((EditText) findViewById(R.id.uname_edit)).getText().toString();
        String pass = ((EditText) findViewById(R.id.pass_edit)).getText().toString();
        String phone = ((EditText) findViewById(R.id.phone_edit)).getText().toString();
        String name = ((EditText) findViewById(R.id.name_edit)).getText().toString();
        RadioGroup rg = (RadioGroup) findViewById(R.id.radioGroup_edit);
        String gender = ((RadioButton)findViewById(rg.getCheckedRadioButtonId()))
                .getText().toString();

        try {
            db.updateUser(new Users(name, uname, pass, phone, gender));
            Toast.makeText(getBaseContext(), "Edited Successfully!!", Toast.LENGTH_SHORT).show();
        }
        catch (SQLiteException exception){
            Toast.makeText(getBaseContext(), "Problem while editing", Toast.LENGTH_SHORT).show();
        }
    }
}