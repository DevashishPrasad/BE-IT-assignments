package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import static java.lang.String.valueOf;

public class Signup extends AppCompatActivity {
    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        try{
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e){}

        db = new DatabaseHandler(this);
    }

    public void checkandsignup(View view){
        String uname = ((EditText) findViewById(R.id.uname_reg)).getText().toString();
        String pass = ((EditText) findViewById(R.id.pass_reg)).getText().toString();
        String phone = ((EditText) findViewById(R.id.phone_reg)).getText().toString();
        String name = ((EditText) findViewById(R.id.name_reg)).getText().toString();
        RadioGroup rg = (RadioGroup) findViewById(R.id.radioGroup);
        String gender = ((RadioButton)findViewById(rg.getCheckedRadioButtonId()))
                        .getText().toString();

        try {
            db.addUser(new Users(name, uname, pass, phone, gender));
            Toast.makeText(getBaseContext(), "Signed Up Successfully!!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        catch (SQLiteException exception){
            Toast.makeText(getBaseContext(), "Username already taken!! Try again with different username", Toast.LENGTH_SHORT).show();
        }
    }
}