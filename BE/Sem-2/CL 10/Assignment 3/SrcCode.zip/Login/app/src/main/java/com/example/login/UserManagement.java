package com.example.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.List;

public class UserManagement extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_management);

        DatabaseHandler db = new DatabaseHandler(this);

        // Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<Users> users = db.getAllUsers();

        Users[] myListData = new Users[users.size()];
        int i = 0;

        for (Users us : users) {
            myListData[i] = us;
            String log = "Id: " + us.getUsername() + " ,Name: " + us.getName() + " ,Phone: " +
                    us.getPhoneNumber()  + " ,Pass: " + us.getPassword();
            // Writing Contacts to log
            Log.d("Name: ", log);

            i++;
        }

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.user_recycler_view);
        UserRecyclerAdapter adapter = new UserRecyclerAdapter(myListData);
        adapter.context = UserManagement.this;
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

    }

    public void gotoAddUser(View view) {
        Intent intent = new Intent(this,UserAdd.class);
        startActivity(intent);
    }
}