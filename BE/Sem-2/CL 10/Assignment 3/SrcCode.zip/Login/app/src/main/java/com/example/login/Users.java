package com.example.login;

public class Users {
    String _name;
    String _phone_number;
    String _password;
    String _username;
    String _gender;


    public Users(){}

    public Users(String name, String uname, String pass, String phone, String gender){
        this._name = name;
        this._phone_number = phone;
        this._username = uname;
        this._password = pass;
        this._gender = gender;
    }
    public String getUsername(){
        return this._username;
    }

    public void setUsername(String uname){
        this._username = uname;
    }

    public String getPassword(){
        return this._password;
    }

    public void setPassword(String pass){
        this._password = pass;
    }

    public String getGender(){
        return this._gender;
    }

    public void setGender(String gender){
        this._gender = gender;
    }

    public String getName(){
        return this._name;
    }

    public void setName(String name){
        this._name = name;
    }

    public String getPhoneNumber(){
        return this._phone_number;
    }

    public void setPhoneNumber(String phone_number){
        this._phone_number = phone_number;
    }

}