package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity {

    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e){}

        db = new DatabaseHandler(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void checkandpass(View view) {
        Intent intent = new Intent(this, Landing.class);
        EditText username = (EditText) findViewById(R.id.uname);
        EditText password = (EditText) findViewById(R.id.pass);
        String uname = username.getText().toString();
        String pass = password.getText().toString();

        Users user = db.getUser(uname);

        if(user == null){
            TextView myTextView = (TextView)findViewById(R.id.error);
            myTextView.setText("Username or password is incorrect");
        }
        else if(user.getUsername().equals(uname) && user.getPassword().equals(pass)) {
            intent.putExtra("uname", uname);
            startActivity(intent);
        }

    }

    public void goSignUp(View view){
        Intent intent = new Intent(this, Signup.class);
        startActivity(intent);
    }
}